﻿
namespace midterm_oquendo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fname = new System.Windows.Forms.Label();
            this.lbl_mname = new System.Windows.Forms.Label();
            this.lbl_lname = new System.Windows.Forms.Label();
            this.lbl_street1 = new System.Windows.Forms.Label();
            this.lbl_street2 = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_state = new System.Windows.Forms.Label();
            this.lbl_zipcode = new System.Windows.Forms.Label();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txt_fname = new System.Windows.Forms.TextBox();
            this.txt_mname = new System.Windows.Forms.TextBox();
            this.txt_lname = new System.Windows.Forms.TextBox();
            this.txt_street1 = new System.Windows.Forms.TextBox();
            this.txt_street2 = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_state = new System.Windows.Forms.TextBox();
            this.txt_zipcode = new System.Windows.Forms.TextBox();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.submit_button = new System.Windows.Forms.Button();
            this.lbl_title = new System.Windows.Forms.Label();
            this.txt_feedback = new System.Windows.Forms.Label();
            this.lbl_instagram = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Instagram = new System.Windows.Forms.TextBox();
            this.txt_cellphone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_fname
            // 
            this.lbl_fname.AutoSize = true;
            this.lbl_fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fname.Location = new System.Drawing.Point(75, 132);
            this.lbl_fname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_fname.Name = "lbl_fname";
            this.lbl_fname.Size = new System.Drawing.Size(102, 22);
            this.lbl_fname.TabIndex = 0;
            this.lbl_fname.Text = "First Name:";
            // 
            // lbl_mname
            // 
            this.lbl_mname.AutoSize = true;
            this.lbl_mname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mname.Location = new System.Drawing.Point(75, 182);
            this.lbl_mname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_mname.Name = "lbl_mname";
            this.lbl_mname.Size = new System.Drawing.Size(119, 22);
            this.lbl_mname.TabIndex = 1;
            this.lbl_mname.Text = "Middle Name:";
            // 
            // lbl_lname
            // 
            this.lbl_lname.AutoSize = true;
            this.lbl_lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lname.Location = new System.Drawing.Point(75, 223);
            this.lbl_lname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_lname.Name = "lbl_lname";
            this.lbl_lname.Size = new System.Drawing.Size(101, 22);
            this.lbl_lname.TabIndex = 2;
            this.lbl_lname.Text = "Last Name:";
            // 
            // lbl_street1
            // 
            this.lbl_street1.AutoSize = true;
            this.lbl_street1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_street1.Location = new System.Drawing.Point(46, 268);
            this.lbl_street1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_street1.Name = "lbl_street1";
            this.lbl_street1.Size = new System.Drawing.Size(188, 22);
            this.lbl_street1.TabIndex = 3;
            this.lbl_street1.Text = "Street Address Line 1:";
            // 
            // lbl_street2
            // 
            this.lbl_street2.AutoSize = true;
            this.lbl_street2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_street2.Location = new System.Drawing.Point(46, 309);
            this.lbl_street2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_street2.Name = "lbl_street2";
            this.lbl_street2.Size = new System.Drawing.Size(188, 22);
            this.lbl_street2.TabIndex = 4;
            this.lbl_street2.Text = "Street Address Line 2:";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(601, 132);
            this.lbl_city.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(46, 22);
            this.lbl_city.TabIndex = 5;
            this.lbl_city.Text = "City:";
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_state.Location = new System.Drawing.Point(601, 182);
            this.lbl_state.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(57, 22);
            this.lbl_state.TabIndex = 6;
            this.lbl_state.Text = "State:";
            // 
            // lbl_zipcode
            // 
            this.lbl_zipcode.AutoSize = true;
            this.lbl_zipcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zipcode.Location = new System.Drawing.Point(601, 227);
            this.lbl_zipcode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_zipcode.Name = "lbl_zipcode";
            this.lbl_zipcode.Size = new System.Drawing.Size(88, 22);
            this.lbl_zipcode.TabIndex = 7;
            this.lbl_zipcode.Text = "Zip Code:";
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone.Location = new System.Drawing.Point(601, 268);
            this.lbl_phone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(135, 22);
            this.lbl_phone.TabIndex = 8;
            this.lbl_phone.Text = "Phone Number:";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(601, 311);
            this.lbl_email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(65, 22);
            this.lbl_email.TabIndex = 9;
            this.lbl_email.Text = "E-Mail:";
            // 
            // txt_fname
            // 
            this.txt_fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fname.Location = new System.Drawing.Point(195, 135);
            this.txt_fname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_fname.Name = "txt_fname";
            this.txt_fname.Size = new System.Drawing.Size(342, 24);
            this.txt_fname.TabIndex = 10;
            // 
            // txt_mname
            // 
            this.txt_mname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mname.Location = new System.Drawing.Point(194, 185);
            this.txt_mname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_mname.Name = "txt_mname";
            this.txt_mname.Size = new System.Drawing.Size(342, 24);
            this.txt_mname.TabIndex = 11;
            // 
            // txt_lname
            // 
            this.txt_lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lname.Location = new System.Drawing.Point(194, 225);
            this.txt_lname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_lname.Name = "txt_lname";
            this.txt_lname.Size = new System.Drawing.Size(342, 24);
            this.txt_lname.TabIndex = 12;
            // 
            // txt_street1
            // 
            this.txt_street1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_street1.Location = new System.Drawing.Point(245, 268);
            this.txt_street1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_street1.Name = "txt_street1";
            this.txt_street1.Size = new System.Drawing.Size(291, 24);
            this.txt_street1.TabIndex = 13;
            // 
            // txt_street2
            // 
            this.txt_street2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_street2.Location = new System.Drawing.Point(245, 309);
            this.txt_street2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_street2.Name = "txt_street2";
            this.txt_street2.Size = new System.Drawing.Size(291, 24);
            this.txt_street2.TabIndex = 14;
            // 
            // txt_city
            // 
            this.txt_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_city.Location = new System.Drawing.Point(659, 135);
            this.txt_city.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(252, 24);
            this.txt_city.TabIndex = 16;
            // 
            // txt_state
            // 
            this.txt_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_state.Location = new System.Drawing.Point(659, 186);
            this.txt_state.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_state.Name = "txt_state";
            this.txt_state.Size = new System.Drawing.Size(252, 24);
            this.txt_state.TabIndex = 17;
            // 
            // txt_zipcode
            // 
            this.txt_zipcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_zipcode.Location = new System.Drawing.Point(746, 227);
            this.txt_zipcode.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_zipcode.Name = "txt_zipcode";
            this.txt_zipcode.Size = new System.Drawing.Size(165, 24);
            this.txt_zipcode.TabIndex = 18;
            // 
            // txt_phone
            // 
            this.txt_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone.Location = new System.Drawing.Point(745, 268);
            this.txt_phone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(166, 24);
            this.txt_phone.TabIndex = 19;
            // 
            // txt_email
            // 
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(667, 310);
            this.txt_email.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(244, 24);
            this.txt_email.TabIndex = 20;
            // 
            // submit_button
            // 
            this.submit_button.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_button.Location = new System.Drawing.Point(471, 427);
            this.submit_button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.submit_button.Name = "submit_button";
            this.submit_button.Size = new System.Drawing.Size(122, 30);
            this.submit_button.TabIndex = 22;
            this.submit_button.Text = "Submit";
            this.submit_button.UseVisualStyleBackColor = true;
            this.submit_button.Click += new System.EventHandler(this.submit_button_Click);
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title.Location = new System.Drawing.Point(53, 64);
            this.lbl_title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(246, 31);
            this.lbl_title.TabIndex = 21;
            this.lbl_title.Text = "Enter Account Info:";
            // 
            // txt_feedback
            // 
            this.txt_feedback.AutoSize = true;
            this.txt_feedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_feedback.Location = new System.Drawing.Point(423, 483);
            this.txt_feedback.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.txt_feedback.Name = "txt_feedback";
            this.txt_feedback.Size = new System.Drawing.Size(127, 18);
            this.txt_feedback.TabIndex = 22;
            this.txt_feedback.Text = "Feedback Results";
            this.txt_feedback.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_instagram
            // 
            this.lbl_instagram.AutoSize = true;
            this.lbl_instagram.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instagram.Location = new System.Drawing.Point(141, 347);
            this.lbl_instagram.Name = "lbl_instagram";
            this.lbl_instagram.Size = new System.Drawing.Size(93, 22);
            this.lbl_instagram.TabIndex = 23;
            this.lbl_instagram.Text = "Instagram:";
            this.lbl_instagram.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(601, 347);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 22);
            this.label2.TabIndex = 24;
            this.label2.Text = "Cell Phone:";
            // 
            // txt_Instagram
            // 
            this.txt_Instagram.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Instagram.Location = new System.Drawing.Point(245, 347);
            this.txt_Instagram.Name = "txt_Instagram";
            this.txt_Instagram.Size = new System.Drawing.Size(134, 24);
            this.txt_Instagram.TabIndex = 15;
            // 
            // txt_cellphone
            // 
            this.txt_cellphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cellphone.Location = new System.Drawing.Point(746, 347);
            this.txt_cellphone.Name = "txt_cellphone";
            this.txt_cellphone.Size = new System.Drawing.Size(165, 24);
            this.txt_cellphone.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 690);
            this.Controls.Add(this.txt_cellphone);
            this.Controls.Add(this.txt_Instagram);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_instagram);
            this.Controls.Add(this.txt_feedback);
            this.Controls.Add(this.lbl_title);
            this.Controls.Add(this.submit_button);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_phone);
            this.Controls.Add(this.txt_zipcode);
            this.Controls.Add(this.txt_state);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_street2);
            this.Controls.Add(this.txt_street1);
            this.Controls.Add(this.txt_lname);
            this.Controls.Add(this.txt_mname);
            this.Controls.Add(this.txt_fname);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_phone);
            this.Controls.Add(this.lbl_zipcode);
            this.Controls.Add(this.lbl_state);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_street2);
            this.Controls.Add(this.lbl_street1);
            this.Controls.Add(this.lbl_lname);
            this.Controls.Add(this.lbl_mname);
            this.Controls.Add(this.lbl_fname);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_fname;
        private System.Windows.Forms.Label lbl_mname;
        private System.Windows.Forms.Label lbl_lname;
        private System.Windows.Forms.Label lbl_street1;
        private System.Windows.Forms.Label lbl_street2;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.Label lbl_zipcode;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txt_fname;
        private System.Windows.Forms.TextBox txt_mname;
        private System.Windows.Forms.TextBox txt_lname;
        private System.Windows.Forms.TextBox txt_street1;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_state;
        private System.Windows.Forms.TextBox txt_zipcode;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Button submit_button;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Label txt_feedback;
        private System.Windows.Forms.TextBox txt_street2;
        private System.Windows.Forms.Label lbl_instagram;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Instagram;
        private System.Windows.Forms.TextBox txt_cellphone;
    }
}

