﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week5_class
{
    class BasicTools
    {
        static void CopyrightMsg()
        {
            MessageBox.Show("Copyright 2021 - Lambert Industries");
        }

    }
}
