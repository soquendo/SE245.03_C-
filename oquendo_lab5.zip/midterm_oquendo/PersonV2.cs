﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace midterm_oquendo
{
    class PersonV2 : Person
    {
        private string cellphone;
        private string instaURL;

        public string Cellphone
        {
            get
            {
                return cellphone;
            }

            set
            {
                if (ValidationLibrary.isNotThis(value.Length, 10) == true)
                {
                    Feedback += "\nERROR: Please enter 10 digit number (Ex. 4015559797";
                }
                if (ValidationLibrary.IsItNum(value) == false)
                {
                    Feedback += "\nERROR: Invalid Cell Phone number - Please enter digits.";
                }
                else
                {
                    cellphone = value;
                }
            }
        }

        public string IG
        {
            get
            {
                return instaURL;
            }

            set
            {
                if (ValidationLibrary.IsItValidIG(value) == true)
                {
                    instaURL = value;
                }
                if (ValidationLibrary.IsItFilledInsta(value) == true)
                {
                    instaURL = value;
                }
                else
                {
                    Feedback += "ERROR: Enter Instagram URL (Ex. instagram.com/username";
                }
                
            }
        }

        public PersonV2() : base()
        {
            Cellphone = "";
            IG = "";
        }

    }
    
}

