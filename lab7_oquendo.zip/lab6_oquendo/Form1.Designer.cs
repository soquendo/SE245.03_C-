﻿
namespace lab6_oquendo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_fname = new System.Windows.Forms.Label();
            this.lbl_mname = new System.Windows.Forms.Label();
            this.lbl_lname = new System.Windows.Forms.Label();
            this.lbl_street1 = new System.Windows.Forms.Label();
            this.lbl_street2 = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_state = new System.Windows.Forms.Label();
            this.lbl_zipcode = new System.Windows.Forms.Label();
            this.lbl_phone = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txt_fname = new System.Windows.Forms.TextBox();
            this.txt_mname = new System.Windows.Forms.TextBox();
            this.txt_lname = new System.Windows.Forms.TextBox();
            this.txt_street1 = new System.Windows.Forms.TextBox();
            this.txt_street2 = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.txt_state = new System.Windows.Forms.TextBox();
            this.txt_zipcode = new System.Windows.Forms.TextBox();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.submit_button = new System.Windows.Forms.Button();
            this.lbl_title = new System.Windows.Forms.Label();
            this.txt_feedback = new System.Windows.Forms.Label();
            this.lbl_instagram = new System.Windows.Forms.Label();
            this.lbl_cellphone = new System.Windows.Forms.Label();
            this.txt_Instagram = new System.Windows.Forms.TextBox();
            this.txt_cellphone = new System.Windows.Forms.TextBox();
            this.sample = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_fname
            // 
            this.lbl_fname.AutoSize = true;
            this.lbl_fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fname.Location = new System.Drawing.Point(165, 142);
            this.lbl_fname.Name = "lbl_fname";
            this.lbl_fname.Size = new System.Drawing.Size(147, 30);
            this.lbl_fname.TabIndex = 0;
            this.lbl_fname.Text = "First Name:";
            // 
            // lbl_mname
            // 
            this.lbl_mname.AutoSize = true;
            this.lbl_mname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mname.Location = new System.Drawing.Point(166, 203);
            this.lbl_mname.Name = "lbl_mname";
            this.lbl_mname.Size = new System.Drawing.Size(172, 30);
            this.lbl_mname.TabIndex = 1;
            this.lbl_mname.Text = "Middle Name:";
            // 
            // lbl_lname
            // 
            this.lbl_lname.AutoSize = true;
            this.lbl_lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lname.Location = new System.Drawing.Point(166, 271);
            this.lbl_lname.Name = "lbl_lname";
            this.lbl_lname.Size = new System.Drawing.Size(144, 30);
            this.lbl_lname.TabIndex = 2;
            this.lbl_lname.Text = "Last Name:";
            // 
            // lbl_street1
            // 
            this.lbl_street1.AutoSize = true;
            this.lbl_street1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_street1.Location = new System.Drawing.Point(123, 340);
            this.lbl_street1.Name = "lbl_street1";
            this.lbl_street1.Size = new System.Drawing.Size(265, 30);
            this.lbl_street1.TabIndex = 3;
            this.lbl_street1.Text = "Street Address Line 1:";
            // 
            // lbl_street2
            // 
            this.lbl_street2.AutoSize = true;
            this.lbl_street2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_street2.Location = new System.Drawing.Point(123, 403);
            this.lbl_street2.Name = "lbl_street2";
            this.lbl_street2.Size = new System.Drawing.Size(265, 30);
            this.lbl_street2.TabIndex = 4;
            this.lbl_street2.Text = "Street Address Line 2:";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(956, 142);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(65, 30);
            this.lbl_city.TabIndex = 5;
            this.lbl_city.Text = "City:";
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_state.Location = new System.Drawing.Point(956, 211);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(79, 30);
            this.lbl_state.TabIndex = 6;
            this.lbl_state.Text = "State:";
            // 
            // lbl_zipcode
            // 
            this.lbl_zipcode.AutoSize = true;
            this.lbl_zipcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zipcode.Location = new System.Drawing.Point(956, 277);
            this.lbl_zipcode.Name = "lbl_zipcode";
            this.lbl_zipcode.Size = new System.Drawing.Size(124, 30);
            this.lbl_zipcode.TabIndex = 7;
            this.lbl_zipcode.Text = "Zip Code:";
            // 
            // lbl_phone
            // 
            this.lbl_phone.AutoSize = true;
            this.lbl_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phone.Location = new System.Drawing.Point(956, 340);
            this.lbl_phone.Name = "lbl_phone";
            this.lbl_phone.Size = new System.Drawing.Size(192, 30);
            this.lbl_phone.TabIndex = 8;
            this.lbl_phone.Text = "Phone Number:";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(270, 458);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(94, 30);
            this.lbl_email.TabIndex = 9;
            this.lbl_email.Text = "E-Mail:";
            // 
            // txt_fname
            // 
            this.txt_fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_fname.Location = new System.Drawing.Point(345, 146);
            this.txt_fname.Name = "txt_fname";
            this.txt_fname.Size = new System.Drawing.Size(511, 32);
            this.txt_fname.TabIndex = 10;
            // 
            // txt_mname
            // 
            this.txt_mname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mname.Location = new System.Drawing.Point(345, 208);
            this.txt_mname.Name = "txt_mname";
            this.txt_mname.Size = new System.Drawing.Size(511, 32);
            this.txt_mname.TabIndex = 11;
            // 
            // txt_lname
            // 
            this.txt_lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lname.Location = new System.Drawing.Point(345, 274);
            this.txt_lname.Name = "txt_lname";
            this.txt_lname.Size = new System.Drawing.Size(511, 32);
            this.txt_lname.TabIndex = 12;
            // 
            // txt_street1
            // 
            this.txt_street1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_street1.Location = new System.Drawing.Point(422, 340);
            this.txt_street1.Name = "txt_street1";
            this.txt_street1.Size = new System.Drawing.Size(434, 32);
            this.txt_street1.TabIndex = 13;
            // 
            // txt_street2
            // 
            this.txt_street2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_street2.Location = new System.Drawing.Point(422, 403);
            this.txt_street2.Name = "txt_street2";
            this.txt_street2.Size = new System.Drawing.Size(434, 32);
            this.txt_street2.TabIndex = 14;
            // 
            // txt_city
            // 
            this.txt_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_city.Location = new System.Drawing.Point(1042, 142);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(394, 32);
            this.txt_city.TabIndex = 18;
            // 
            // txt_state
            // 
            this.txt_state.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_state.Location = new System.Drawing.Point(1042, 208);
            this.txt_state.Name = "txt_state";
            this.txt_state.Size = new System.Drawing.Size(394, 32);
            this.txt_state.TabIndex = 19;
            // 
            // txt_zipcode
            // 
            this.txt_zipcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_zipcode.Location = new System.Drawing.Point(1188, 277);
            this.txt_zipcode.Name = "txt_zipcode";
            this.txt_zipcode.Size = new System.Drawing.Size(248, 32);
            this.txt_zipcode.TabIndex = 20;
            // 
            // txt_phone
            // 
            this.txt_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone.Location = new System.Drawing.Point(1186, 340);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(250, 32);
            this.txt_phone.TabIndex = 21;
            // 
            // txt_email
            // 
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(422, 455);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(328, 32);
            this.txt_email.TabIndex = 24;
            // 
            // submit_button
            // 
            this.submit_button.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submit_button.Location = new System.Drawing.Point(768, 649);
            this.submit_button.Name = "submit_button";
            this.submit_button.Size = new System.Drawing.Size(183, 46);
            this.submit_button.TabIndex = 26;
            this.submit_button.Text = "Submit";
            this.submit_button.UseVisualStyleBackColor = true;
            this.submit_button.Click += new System.EventHandler(this.submit_button_Click);
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_title.Location = new System.Drawing.Point(98, 58);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(361, 46);
            this.lbl_title.TabIndex = 21;
            this.lbl_title.Text = "Enter Account Info:";
            // 
            // txt_feedback
            // 
            this.txt_feedback.AutoSize = true;
            this.txt_feedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_feedback.Location = new System.Drawing.Point(538, 755);
            this.txt_feedback.Name = "txt_feedback";
            this.txt_feedback.Size = new System.Drawing.Size(186, 26);
            this.txt_feedback.TabIndex = 31;
            this.txt_feedback.Text = "Feedback Results";
            this.txt_feedback.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_instagram
            // 
            this.lbl_instagram.AutoSize = true;
            this.lbl_instagram.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instagram.Location = new System.Drawing.Point(956, 458);
            this.lbl_instagram.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_instagram.Name = "lbl_instagram";
            this.lbl_instagram.Size = new System.Drawing.Size(133, 30);
            this.lbl_instagram.TabIndex = 23;
            this.lbl_instagram.Text = "Instagram:";
            this.lbl_instagram.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lbl_cellphone
            // 
            this.lbl_cellphone.AutoSize = true;
            this.lbl_cellphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cellphone.Location = new System.Drawing.Point(956, 403);
            this.lbl_cellphone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cellphone.Name = "lbl_cellphone";
            this.lbl_cellphone.Size = new System.Drawing.Size(145, 30);
            this.lbl_cellphone.TabIndex = 24;
            this.lbl_cellphone.Text = "Cell Phone:";
            // 
            // txt_Instagram
            // 
            this.txt_Instagram.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Instagram.Location = new System.Drawing.Point(1186, 455);
            this.txt_Instagram.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Instagram.Name = "txt_Instagram";
            this.txt_Instagram.Size = new System.Drawing.Size(248, 32);
            this.txt_Instagram.TabIndex = 23;
            // 
            // txt_cellphone
            // 
            this.txt_cellphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cellphone.Location = new System.Drawing.Point(1186, 400);
            this.txt_cellphone.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_cellphone.Name = "txt_cellphone";
            this.txt_cellphone.Size = new System.Drawing.Size(248, 32);
            this.txt_cellphone.TabIndex = 22;
            // 
            // sample
            // 
            this.sample.Location = new System.Drawing.Point(1337, 650);
            this.sample.Name = "sample";
            this.sample.Size = new System.Drawing.Size(99, 46);
            this.sample.TabIndex = 36;
            this.sample.Text = "sample";
            this.sample.UseVisualStyleBackColor = true;
            this.sample.Click += new System.EventHandler(this.sample_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1692, 1040);
            this.Controls.Add(this.sample);
            this.Controls.Add(this.txt_cellphone);
            this.Controls.Add(this.txt_Instagram);
            this.Controls.Add(this.lbl_cellphone);
            this.Controls.Add(this.lbl_instagram);
            this.Controls.Add(this.txt_feedback);
            this.Controls.Add(this.lbl_title);
            this.Controls.Add(this.submit_button);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_phone);
            this.Controls.Add(this.txt_zipcode);
            this.Controls.Add(this.txt_state);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.txt_street2);
            this.Controls.Add(this.txt_street1);
            this.Controls.Add(this.txt_lname);
            this.Controls.Add(this.txt_mname);
            this.Controls.Add(this.txt_fname);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_phone);
            this.Controls.Add(this.lbl_zipcode);
            this.Controls.Add(this.lbl_state);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_street2);
            this.Controls.Add(this.lbl_street1);
            this.Controls.Add(this.lbl_lname);
            this.Controls.Add(this.lbl_mname);
            this.Controls.Add(this.lbl_fname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_fname;
        private System.Windows.Forms.Label lbl_mname;
        private System.Windows.Forms.Label lbl_lname;
        private System.Windows.Forms.Label lbl_street1;
        private System.Windows.Forms.Label lbl_street2;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.Label lbl_zipcode;
        private System.Windows.Forms.Label lbl_phone;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txt_fname;
        private System.Windows.Forms.TextBox txt_mname;
        private System.Windows.Forms.TextBox txt_lname;
        private System.Windows.Forms.TextBox txt_street1;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.TextBox txt_state;
        private System.Windows.Forms.TextBox txt_zipcode;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Button submit_button;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Label txt_feedback;
        private System.Windows.Forms.TextBox txt_street2;
        private System.Windows.Forms.Label lbl_instagram;
        private System.Windows.Forms.Label lbl_cellphone;
        private System.Windows.Forms.TextBox txt_Instagram;
        private System.Windows.Forms.TextBox txt_cellphone;
        private System.Windows.Forms.Button sample;
    }
}

